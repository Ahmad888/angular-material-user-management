import { Component } from '@angular/core';
import { UserService } from '../../services/user';
import { FormControl } from '@angular/forms';
import { Subject, takeUntil } from 'rxjs';
import { User } from '../../models/user.models';

@Component({
  selector: 'app-user-list',
  imports: [],
  templateUrl: './user-list.html',
  styleUrl: './user-list.css',
})
export class UserList {
  allUsers: User[] = [];
  filteredUsers: User[] = [];
  searchControl = new FormControl('');

  isLoading = false;
  hasError = false;

  private destroy$ = new Subject<void>();

  constructor(private userService: UserService) {}

  ngOnInit(): void {
    console.log('initial state');
    this.loadUsers();
  }

  loadUsers(): void {
    this.isLoading = true;
    this.hasError = false;

    this.userService.getUsers().pipe(takeUntil(this.destroy$))
      .subscribe({
        next: (users) => {
          console.log(users);
          this.allUsers = users;
          this.filteredUsers = users;
          this.isLoading = false;
        },
        error: (err) => {
          console.log(err);
          this.isLoading = false;
          this.hasError = true;
        }
      })
  }

  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
}
