import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, catchError, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { User } from '../models/user.models';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  // private apiUrl: 'https://jsonplaceholder.typicode.com/users';
  // private selectedUserSubject: new BehaviorSubject<User | null>(null);

  // selectedUser$: this.selectedUserSubject.asObservable();

  constructor(private http: HttpClient) {}

  getUsers(): Observable<User[]> {
    return this.http.get<User[]>('https://jsonplaceholder.typicode.com/users').pipe(
      catchError(error => {
        console.error('Error Fetching details:' ,error);
        return of([]);
      })
    );
  }

  // setSelectedUser(user: User | null): void {
    // this.selectedUserSubject.next(user);
  // }
}
